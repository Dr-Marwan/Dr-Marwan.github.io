<?php
/**
 * The style "default" of the Widget "Contacts"
 *
 * @package WordPress
 * @subpackage ThemeREX Addons
 * @since v1.6.10
 */

$args = get_query_var('trx_addons_args_widget_contacts');
extract($args);
		
// Before widget (defined by themes)
trx_addons_show_layout($before_widget);
			
// Widget title if one was input (before and after defined by themes)
trx_addons_show_layout($title, $before_title, $after_title);
	
// Widget body
if (!empty($logo)) {
	?><div class="contacts_logo"><?php echo trim($logo); ?></div><?php
}
if (!empty($description)) {
	?><div class="contacts_description"><?php echo wpautop($description); ?></div><?php
}
$show_info = !empty($address) || !empty($phone) || !empty($email);
if (!$show_info) $googlemap_position = 'top';
if ($show_info || !empty($googlemap)) {
	if ($show_info && !empty($googlemap)) {
		?><div class="contacts_place contacts_map_<?php echo esc_attr($googlemap_position); ?>"><?php
	}
	if (!empty($googlemap) && !empty($address) && function_exists('trx_addons_sc_googlemap')) {
		trx_addons_show_layout(trx_addons_sc_googlemap(array(
												'address' => str_replace('|', "", $address),
												'height' => $googlemap_height,
												'zoom' => 10
												)), '<div class="contacts_map">', '</div>');
	}
	if (!empty($address) || !empty($phone) || !empty($email) || !empty($worktime)) {
		?><div class="contacts_info"><?php
			if (!empty($phone) || !empty($email) || !empty($address)) {
				?><div class="contacts_right"><?php
				if (!empty($address)) {
					?><span class="contacts_address"><?php echo str_replace('|', "<br>", $address); ?></span><?php
				}
				if (!empty($worktime)) {
					?><div class="contacts_worktime"><?php echo wpautop($worktime); ?></div><?php
				}
				if (!empty($phone)) {
					?><span class="contacts_phone"><a href="tel:<?php echo esc_attr($phone); ?>"><?php echo esc_html($phone); ?></a></span><?php
				}
				if (!empty($email)) {
					?><span class="contacts_email"><a href="mailto:<?php echo esc_attr($email); ?>"><?php echo trim($email); ?></a></span><?php
				}
				?></div><?php
			}
		?></div><?php
	}
	if ($show_info && !empty($googlemap)) {
		?></div><?php
	}
}

// Social icons
if ( $socials && ($output = trx_addons_get_socials_links()) != '') {
	?><div class="contacts_socials socials_wrap"><?php trx_addons_show_layout($output); ?></div><?php
}

// Custom content
if ( !empty($content) ) {
	?><div class="contacts_content"><?php trx_addons_show_layout($content); ?></div><?php
}
	
// After widget (defined by themes)
trx_addons_show_layout($after_widget);
?>